"""The models every route validates against."""

from pydantic import BaseModel, Field, field_validator

from config import constants
from metermind.core import validators


class HealthReply(BaseModel):
    service: str
    status: str


class ReadingSubmission(BaseModel):
    account_number: str
    meter_serial: str
    consumer_category: str
    billing_period: str
    sanctioned_load_kw: float = Field(gt=0, le=500)
    cycle_days: int = Field(ge=constants.MINIMUM_CYCLE_DAYS, le=constants.MAXIMUM_CYCLE_DAYS)
    previous_reading: float = Field(ge=0, lt=constants.METER_ROLLOVER_UNITS)
    current_reading: float = Field(ge=0, lt=constants.METER_ROLLOVER_UNITS)
    read_type: str = "actual"

    @field_validator("account_number")
    @classmethod
    def account_number_is_well_formed(cls, given):
        if not validators.validate_account_number(given):
            raise ValueError("account_number must look like ACC10000000")
        return given.strip().upper()

    @field_validator("meter_serial")
    @classmethod
    def meter_serial_is_well_formed(cls, given):
        if not validators.validate_meter_serial(given):
            raise ValueError("meter_serial must look like MTR-AB-123456")
        return given

    @field_validator("billing_period")
    @classmethod
    def billing_period_is_well_formed(cls, given):
        if not validators.validate_billing_period(given):
            raise ValueError("billing_period must look like 2026-06")
        return given


class ReadingReply(BaseModel):
    reading_id: str
    account_number: str
    consumer_category: str
    units_consumed: float
    energy_charge_inr: float
    fixed_charge_inr: float
    net_bill_inr: float
    is_billable: bool
    refusal_reasons: list[str]


class CaseStatusRequest(BaseModel):
    wanted_status: str
    noted_by: str


class CaseStatusReply(BaseModel):
    reading_id: str
    from_status: str
    to_status: str
    recorded_by: str


class PagedReadings(BaseModel):
    readings: list[ReadingReply]
    page: int
    page_size: int
    total: int
