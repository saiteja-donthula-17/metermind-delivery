"""Every node the assistant's graph runs, plain functions taking and returning state updates."""

from config import constants

category_model_path = constants.COMPLAINT_CATEGORY_MODEL_PATH
urgency_model_path = constants.COMPLAINT_URGENCY_MODEL_PATH
loaded_classifiers = {}


def _load_classifiers_once():
    if "category" not in loaded_classifiers:
        from metermind.exception_models.baseline_model import load_model
        loaded_classifiers["category"] = load_model(category_model_path)
        loaded_classifiers["urgency"] = load_model(urgency_model_path)
    return loaded_classifiers["category"], loaded_classifiers["urgency"]


def triage_the_question(state):
    question = state.get("question", "")
    if not question or not question.strip():
        return {
            "finished": True,
            "refusal": "there is not enough here to work with",
            "steps": ["triage"],
        }

    category_model, urgency_model = _load_classifiers_once()
    category = category_model.predict([question])[0]
    urgency = urgency_model.predict([question])[0]

    return {"category": category, "urgency": urgency, "steps": ["triage"]}
